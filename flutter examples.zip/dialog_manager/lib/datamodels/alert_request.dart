class AlertRequest {
  final String title;
  final String description;
  final String buttonTitle;

  AlertRequest({
    this.title,
    this.description,
    this.buttonTitle,
  });
}
